#include <bits/stdc++.h>
using namespace std;
int main(){  
    // 1.字符串的比较
    char s3[]="ABCD";
    cout<<strcmp(s3,"AB34")<<endl;
    cout<<strcmp(s3,"ABcd")<<endl;
	cout<<strcmp(s3,"ABC")<<endl;
    cout<<strcmp(s3,"ABCD")<<endl;
    
    // 2.字符串的拼接
    char s4[100]= "good";
    strcat(s4,"morning");
    cout<<s4<<endl;
	
	string s1="good morning";
	char ch='c';
	cout<<s1+ch<<endl;
	
  
	return 0;
}
