#include <bits/stdc++.h>
using namespace std;
int main(){    
    char a[1001]={0};
    char b[1001]={0};
    cin>>a>>b;
    char t[1001]={0};
    strcpy(t,a);
    strcpy(a,b);
    strcpy(b,t);
    cout<<a<<endl;
    cout<<b<<endl;
    return 0;
}
