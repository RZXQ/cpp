#include <bits/stdc++.h>
using namespace std;
int main(){  
    // 拼接姓名
    char a[201]={0};
    char b[201]={0};
    cin>>a>>b;
    if(strcmp(a,b)>=0){
        strcat(b,a);
        cout<<b<<endl;
    }else{
        strcat(a,b);
        cout<<a<<endl;
    }  
    return 0;
}
