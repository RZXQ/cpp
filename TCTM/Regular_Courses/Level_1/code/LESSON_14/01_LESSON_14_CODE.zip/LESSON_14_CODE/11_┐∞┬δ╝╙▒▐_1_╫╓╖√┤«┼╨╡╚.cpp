#include <bits/stdc++.h>
using namespace std;

int main(){
	//字符串判等
	char s1[256]={0},s2[256]={0};
	cin.getline(s1, 256);
	cin.getline(s2, 256);
	char a[256]={0},b[256]={0};
	int ai=0;
	for(int i=0;i<strlen(s1);i++){
		if(s1[i]!=' '){
			a[ai]=s1[i];
			ai++;
		}
	}
	int bi=0;
	for(int i=0;i<strlen(s2);i++){
		if(s2[i]!=' '){
			b[bi]=s2[i];
			bi++;
		}
	}
	if(strcmp(a,b)==0) cout<<"YES";
	else cout<<"NO";	
	return 0;
}
