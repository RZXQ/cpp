#include <iostream>
using namespace std;
int main(){
    // 字符数组存储字符串
    char c[6] = {'h','e','l','l','o','\0'};
    cout<<c<<endl;
	char c1[6] = {'h','e','l','l','o',0};
	cout<<c1<<endl;
	char c2[6] = "hello"; 
	cout<<c2<<endl;
    char c3[] = {'h','e','l','l','o',0};
    cout<<c3<<endl;
    char c4[] = "hello"; 
    cout<<c4<<endl;
    return 0;
}
