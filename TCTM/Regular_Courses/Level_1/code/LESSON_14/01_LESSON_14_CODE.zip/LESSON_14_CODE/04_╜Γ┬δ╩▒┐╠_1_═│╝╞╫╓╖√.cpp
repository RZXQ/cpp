#include <iostream>
using namespace std;
int main(){
    // 1、接受用户的输入
	char s[1001]={0};
    cin.getline(s,1000);
//    cout<<s<<endl;
    // 2、统计字符串的长度和数字的个数
    int i=0,c=0;
    while(s[i]!=0){
        // 统计数字的个数
        if(s[i]>=48 && s[i]<=57)c++;
        // 统计字符串的长度
        i++;
    }
	// 3、按要求输出
    cout<<i<<endl;
    cout<<c<<endl;
    return 0;
}
