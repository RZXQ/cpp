#include <bits/stdc++.h>
#include <cstring>
using namespace std;
int main(){
    // 1.计算字符串的长度
    char s[] = "hello";
    cout<<strlen(s)<<endl;
   // 2、字符串的遍历
    for(int i=0;i<strlen(s);i++){
        cout<<s[i]<<endl;
    }
    return 0;
}
