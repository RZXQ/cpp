#include <iostream>
using namespace std;
int main(){
    // '\0'控制符
    char c[] = {'a','b','c','\0','1','2','3'};
    cout<<c<<endl;
    return 0;
}