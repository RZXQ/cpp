#include <bits/stdc++.h>
using namespace std;
int main(){    
    // 1.修改和重新赋值
    char s1[] = "hello";
    s1[0] = 'H';
    cout<<s1<<endl;
    // s1 = "good"; 数组名是常量，不能给数组名赋值
    // 2.strcpy strncpy
    strcpy(s1,"good");
    cout<<s1<<endl;
    char s2[] = "morning!"; 
    strncpy(s1,s2,strlen(s1));
    cout<<s1<<endl;
    return 0;
}
