#include <bits/stdc++.h>
using namespace std;

int main(){
	//宝库的钥匙
	char b[51]={0},c[51]={0};
	cin>>b>>c;
	int a=strlen(b)/2;
	for (int i=0;i<a;i++){
		cout<<b[i];
	}
	cout<<c;
	for(int j=a;j<strlen(b);j++){
		cout<<b[j];
	}
	return 0;
}
