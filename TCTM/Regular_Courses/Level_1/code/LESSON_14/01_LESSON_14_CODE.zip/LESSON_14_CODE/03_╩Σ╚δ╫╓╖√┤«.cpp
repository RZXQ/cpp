#include <iostream>
using namespace std;
int main(){
    // 1、输入字符串
    char s[20] = {0};
    cin>>s;
	cout<<s<<endl;
	// 2、输入空格
	cin.getline(s,20);
	cout<<s<<endl;
    return 0;
}
