#include <iostream>
using namespace std;
int main(){
	//1、创建char类型变量c
	char c;
	//接收键盘输入小写字母
	cin >> c;
	//2、将小写字母转为大写字母
	c = c - 32;
	//3、输出转换结果
	cout << c;
	return 0;
}
