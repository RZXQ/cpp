#include <iostream>
using namespace std;
int main(){
	//1、创建Char类型变量
	char c;
	//接收键盘输入
	cin>>c;
	//2、找到对应的ASCII码
	int a=c;
	//3、输出结果
	cout<<a;
	return 0;
}
