#include <iostream>
using namespace std;
int main(){
	//1、创建char类型的变量保存两个字符信号
	char c1,c2;
	cin>>c1>>c2;
	//2、解密第一个信号
	c1=c1-5;
	//解密第二个信号
	c2=c2+4;
	//3、输出解密之后的信号内容
	cout<<c1<<" "<<c2;
	return 0;
}
