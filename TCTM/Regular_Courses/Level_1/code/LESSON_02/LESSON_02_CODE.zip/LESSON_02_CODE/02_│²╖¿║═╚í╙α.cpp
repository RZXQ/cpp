#include <iostream>
using namespace std;
int main(){
	int a=50,b=3;
	int c = a/b;
	cout<<c<<endl;
	int d = a%b;
	cout<<d<<endl;
	return 0;
}
