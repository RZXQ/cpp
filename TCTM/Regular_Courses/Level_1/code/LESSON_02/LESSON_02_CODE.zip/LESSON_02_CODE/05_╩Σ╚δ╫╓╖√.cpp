#include <iostream>
using namespace std;
int main(){
	char d;
	cin>>d;
	cout<<d;
	return 0;
}
