#include <iostream>
using namespace std;
int main(){
	int a,b;
	cin>>a>>b;
	int c=(a+b)*2;
	int d=a*b;
	cout<<c<<" "<<d<<endl;
	return 0;
}
