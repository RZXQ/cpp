#include<bits/stdc++.h>
using namespace std;
int main() {
	string a,b;
	getline(cin,a);
	getline(cin,b);
	int cnt=0;
	int pos=a.find(b);
	while(pos!=-1) {
		cnt++;
		pos=a.find(b,pos+1);
	}
	cout<<cnt;
	return 0;
}
