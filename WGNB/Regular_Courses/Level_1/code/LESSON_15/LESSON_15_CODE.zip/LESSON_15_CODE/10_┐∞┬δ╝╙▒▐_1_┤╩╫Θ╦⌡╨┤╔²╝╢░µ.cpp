#include <bits/stdc++.h>
using namespace std;

int main(){
	//词组缩写
	string s;
	getline(cin,s);
	string ss="";
	// 追加第一个单词的首字母
	ss+=s[0];
	// 追加后面单词的首字母
	for(int i=1; i<s.length(); i++){
		// 不是空格就过
		if(s[i]!=' ')continue;
		if(s[i+1]!=' ') ss+=s[i+1];			
	}
	// 小写转大写
	for(int i=0;i<ss.length();i++){
		if('a'<=ss[i]&&ss[i]<='z')ss[i]-=32;
	}
	cout<<ss;
	return 0;
}
