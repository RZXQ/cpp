#include <iostream>
using namespace std;
int main(){
	string s="Hello";
	int n=s.find("ll"); 
	int m=s.find("kk");
	cout<<n<<endl; 
	cout<<m<<endl;
	string s1="hellollo";
	int a=s.find("ll");
	cout<<a<<endl;
	return 0;
}


