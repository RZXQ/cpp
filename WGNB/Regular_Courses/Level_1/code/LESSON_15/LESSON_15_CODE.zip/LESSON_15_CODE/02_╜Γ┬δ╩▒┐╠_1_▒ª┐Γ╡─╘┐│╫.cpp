#include <bits/stdc++.h>
using namespace std;

int main(){
	//宝库的钥匙
	string b,c;
	cin>>b>>c;
	int a=b.length()/2;
	for (int i=0;i<a;i++){
		cout<<b[i];
	}
	cout<<c;
	for(int j=a;j<b.length();j++){
		cout<<b[j];
	}
	return 0;
}
