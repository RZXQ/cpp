#include <iostream>
using namespace std;
int main(){
	// 字符串的拼接
	string s1="hello";
	string s2 = "world";
	cout<<s1+s2<<endl;
	string s3=s1+s2;
	cout<<s3<<endl;
	char c='!';
	string s4=s1+c;
	cout<<s4<<endl;
	// 字符串的追加
	s1 += s2;
	cout <<s1<< endl;
	return 0;
}
