#include <iostream>
using namespace std;
int main(){
	string s1;
	getline(cin, s1);
	string s2=s1;
	//将第一个字母转成大写
	if(s2[0]>='a'&&s1[0]<='z') s2[0]=s2[0]-32; 
	//除开头字母外，其余大写字母均转为小写	
	for(int i=1; i<s2.length(); i++){	
		if(s2[i]>='A'&& s2[i]<='Z') s2[i]=s2[i]+32; 
	}
	cout<<s1<<endl<<s2;
	return 0;
}
