#include <iostream>
using namespace std;
int main(){
	//输入方式
	string s;
//	cin>>s;
//	cout<<s<<endl;	
	getline(cin,s);
	cout<<s<<endl;	
	return 0;
}
