#include<bits/stdc++.h>
using namespace std;
int main(){
	//1、接收输入的两个字符串
	string a,b;
	getline(cin,a);
	getline(cin,b);
	//2、记录查找子串的返回值
	int n=a.find(b);
	//3、根据n的值判断b是否为a的子串
	if(n!=-1){
		cout<<"YES"<<endl;
	}else{
		cout<<"NO"<<endl;
	}
	return 0;
}
