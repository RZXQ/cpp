#include <iostream>
using namespace std;
int main(){
	string s1="abcd";
	string s2="abdd";
	cout<<(s1 > s2)<<endl;
	cout<<(s1 <= s2)<<endl;
	cout<<(s1 == s2)<<endl;
	cout<<(s1 != s2)<<endl;
	return 0;
}
