#include <iostream>
using namespace std;
//定义a函数，输出分界线
void a(){
	cout<<"===================="<<endl;
}
int main(){	
	//使用a函数
	a();
	a();
	a();
	return 0;
}
