#include <iostream>
using namespace std;
int main(){
	int a;
	a=1;
	cout<<a<<endl;
	cout<<a+1<<endl;
	return 0;
}


