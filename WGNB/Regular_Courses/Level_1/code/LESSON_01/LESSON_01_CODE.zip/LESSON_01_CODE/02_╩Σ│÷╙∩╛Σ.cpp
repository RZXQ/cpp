#include <iostream>
using namespace std;
int main(){
	cout<<"Hello world"<<endl;
	cout<<"123456"<<endl;
	cout<<"@:)"<<endl;
	cout<<"你好世界"<<endl;
	return 0;
}
